﻿CREATE USER fitnessground IDENTIFIED BY fitnessground;

GRANT CONNECT, RESOURCE, DBA TO fitnessground;
GRANT ADVISOR TO fitnessground;
GRANT ADMINISTER SQL TUNING SET TO fitnessground;
GRANT SELECT ANY DICTIONARY TO fitnessground;